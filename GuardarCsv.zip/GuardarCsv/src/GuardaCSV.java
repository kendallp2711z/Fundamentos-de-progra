/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kenda
 */
import java.io.File;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
//import java.io.*;


public class GuardaCSV {
    
   public static final String SEPARATOR=";";
   public static final String QUOTE="\"";

    public static String WriteFile(persona per) throws IOException
    {
      
      try 
      {
         String cadena = per.getCadenaT();
         File file = new File ("C:\\Files\\persona.csv");
         FileWriter escribir;
         PrintWriter linea;
         if (!file.exists())
         {
             System.out.println("El Archivo no existe");
             file.createNewFile();
             escribir = new FileWriter(file,true);
             linea = new PrintWriter(escribir);
             linea.println(cadena);
             linea.close();
             escribir.close();
         }
         else
         {
             escribir = new FileWriter(file,true);
             linea = new PrintWriter(escribir);
             linea.println(cadena);
             linea.close();
             escribir.close();
         }
        
         System.out.println("Done");
         
      } 
      catch (Exception e)
      {
         
      } 
      finally 
      {
          
        
        return ("");
 
      }
    }
    
    private static String[] removeTrailingQuotes(String[] fields) {

      String result[] = new String[fields.length];

      for (int i=0;i<result.length;i++){
         result[i] = fields[i].replaceAll("^"+QUOTE, "").replaceAll(QUOTE+"$", "");
      }
      return result;
   }
    
}

