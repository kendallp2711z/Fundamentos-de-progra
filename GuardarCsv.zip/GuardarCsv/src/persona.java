/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author kenda
 */
public class persona <T>
{
    //String nombre = "";
    //String apellidos = "";
    //String edad = "";
    private T dato1;
    private T dato2;
    private T dato3;
    
    public persona()
    {
    }
    
    public void setDato1 (T t) 
    {
        this.dato1 = t;
    }
    public void setDato2 (T t) 
    {
        this.dato2 = t;
    }
    public void setDato3 (T t) 
    {
        this.dato3 = t;
    }

    public T getDato1() 
    {
        return this.dato1;
    }
    public T getDato2() 
    {
        return this.dato2;
    }
    public T getDato3() 
    {
        return this.dato3;
    }
    
    public String getCadenaT () 
    {
        
        String cadena = this.dato1 + ";" + this.dato2 + ";" + this.dato3;
        return cadena;
    }

    /*public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getEdad() {
        return edad;
    }

    public persona() {
    }
    
    public String[] getArrayPersona () 
    {
        
        String[] datos = {nombre, apellidos, String.valueOf(edad)};
        return datos;
    }
    
    public String getCadenaPersona () 
    {
        
        String cadena = this.nombre + ";" + this.apellidos + ";" + this.edad;
        return cadena;
    }*/
    
}
